/* ===========================================================================
   Omple el catàleg d'ítems propis a partir de `assets/js/generadors.js`.

   No escriu cap fitxer: el catàleg surt per stdout i el consumeix
   `tools/compila.py`.

   Els generadors viuen en JavaScript perquè el navegador els ha de poder
   executar: és el que fa que el dau pugui donar «uns altres nombres»
   sense sortir del tipus de pregunta. Perquè no n'hi hagi dues versions,
   la compilació els executa amb Node, aquí, en comptes de tenir-ne una
   còpia en Python.

       node tools/genera.js               escriu tools/items-propis.json
       node tools/genera.js --comprova    verifica els generadors i no escriu
       node tools/genera.js --cataleg     treu el catàleg per stdout
       node tools/genera.js --mostra 200  treu N variants de cada generador

   Què comprova `--comprova`:
     · que cap generador peti en 200 tirades;
     · que sempre torni enunciat (o figura), resposta i passos;
     · que els dòlars de LaTeX estiguin aparellats;
     · que els m.c.d., els m.c.m., les arrels i les diagonals que diu la
       resposta siguin els que surten de recalcular-los.

   El NIVELL no es mesura aquí. El mesurador viu a `tools/compila.py` i és
   l'únic que hi ha; `--mostra` li dona variants perquè comprovi que el
   nivell declarat per cada generador és el que de debò tenen totes.

   La mida del catàleg (`PER_GENERADOR`) només decideix quantes variants
   entren a `banc.js` per triar-ne a l'atzar; el pou del dau és infinit.
   =========================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');

const arrel = path.resolve(__dirname, '..');
global.window = global;
require(path.join(arrel, 'assets/js/atzar.js'));
require(path.join(arrel, 'assets/js/generadors.js'));

const GEN = global.GENERADORS;
const PER_GENERADOR = 6;      // variants de cada generador que van al catàleg
const MOSTRA = 200;           // tirades per generador a --comprova

/* ---------------------------------------------------------------- catàleg */
function catalog() {
  const items = [];
  for (const g of GEN.llista) {
    const vistos = new Set();
    // Es demanen més variants de les que calen: els generadors de llista
    // tancada (definicions, problemes) repeteixen, i els repetits es
    // descarten en comptes de sortir dos cops al banc.
    for (let s = 0; s < PER_GENERADOR * 8 && vistos.size < PER_GENERADOR; s++) {
      const it = GEN.crea(g.id, s);
      const firma = it.cap + '|' + it.enunciat + '|' + (it.figura || '');
      if (vistos.has(firma)) continue;
      vistos.add(firma);
      items.push(it);
    }
  }
  return items;
}

/* -------------------------------------------------------------- comprova */
function net(s) {
  return String(s || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\\[a-zA-Z]+/g, ' ')
    .replace(/[${}\\]/g, '')
    .replace(/\s+/g, ' ').trim();
}

function mcd(a, b) { while (b) { const t = b; b = a % b; a = t; } return a; }

/**
 * Valor d'una expressió en x tal com l'escriuen els generadors: `3x - 5`,
 * `2(x + 4)`, `3 \\cdot (-2)`. Només per a text propi i controlat; no és
 * un analitzador general.
 */
function avalua(expr, x) {
  const js = expr.replace(/\\cdot/g, '*').replace(/\s+/g, '')
    .replace(/(\d)x/g, '$1*x').replace(/(\d)\(/g, '$1*(')
    .replace(/x/g, '(' + x + ')');
  if (!/^[-+*/().\d]+$/.test(js)) throw new Error('expressió inesperada: ' + expr);
  return Function('return (' + js + ');')();
}

/** El primer tros de mode matemàtic d'un text: `$3x + 5 = 20$` -> `3x + 5 = 20`. */
const mat = t => (String(t).match(/\$([^$]*)\$/) || [])[1] || '';
/** `\\dfrac{3}{4}` -> [3, 4]; `0{,}75` -> 0.75. */
const fraccio = t => (t.match(/frac\{(\d+)\}\{(\d+)\}/) || []).slice(1).map(Number);
const decimal = t => parseFloat(t.replace('{,}', '.'));

/** Comprovacions aritmètiques concretes, per generador. */
function aritmetica(it, errors, aplicades) {
  const e = net(it.enunciat), r = net(it.resposta);
  const compta = () => { aplicades[it.gen] = (aplicades[it.gen] || 0) + 1; };
  const malament = que => errors.push(`${it.gen}/${it.llavor}: ${que}`);

  // Equacions: la solució escrita ha de fer iguals els dos membres.
  if (/^equ-/.test(it.gen)) {
    compta();
    const [esq, dre] = mat(it.enunciat).split('=');
    const x = +mat(it.resposta).replace('x =', '');
    if (avalua(esq, x) !== avalua(dre, x)) malament(`x = ${x} no és solució`);
  }
  if (it.gen === 'alg-comprova') {
    compta();
    const [esq, dre] = mat(it.enunciat).split('=');
    const x = +(it.enunciat.match(/x = (-?\d+)\$$/) || [])[1];
    const es = avalua(esq, x) === avalua(dre, x);
    if (es !== /^Sí/.test(it.resposta)) malament('el sí o el no és al revés');
  }
  if (it.gen === 'fd-a-decimal') {
    compta();
    const [a, b] = fraccio(it.enunciat);
    if (Math.abs(a / b - decimal(mat(it.resposta))) > 1e-9) malament('decimal incorrecte');
  }
  if (it.gen === 'fd-a-fraccio') {
    compta();
    const [a, b] = fraccio(it.resposta);
    if (Math.abs(a / b - decimal(mat(it.enunciat))) > 1e-9) malament('fracció incorrecta');
    if (mcd(a, b) !== 1) malament('la fracció no és irreductible');
  }
  if (it.gen === 'pro-regla-tres') {
    compta();
    const [a, p, b] = (it.enunciat.match(/\$(\d+)\$/g) || []).map(x => +x.slice(1, -1));
    if (b * p / a !== +mat(it.resposta)) malament('regla de tres incorrecta');
  }
  if (it.gen === 'are-basica' || it.gen === 'vol-cossos') {
    compta();
    const v = (it.enunciat.match(/\$(\d+)\$/g) || []).map(x => +x.slice(1, -1));
    const esperat = /quadrat/.test(e) ? v[0] * v[0]
      : /triangle/.test(e) ? v[0] * v[1] / 2
      : /cub/.test(e) ? v[0] ** 3
      : v.reduce((a, b) => a * b, 1);
    if (esperat !== +mat(it.resposta)) malament('àrea o volum incorrecte');
  }
  const dos = e.match(/^(-?\d+) i (-?\d+)$/);
  if (it.gen === 'div-mcd' && dos) {
    aplicades['div-mcd'] = (aplicades['div-mcd'] || 0) + 1;
    const v = mcd(+dos[1], +dos[2]);
    if (!r.endsWith('= ' + v)) errors.push(`${it.gen}/${it.llavor}: m.c.d. incorrecte`);
  }
  if (it.gen === 'div-mcm' && dos) {
    aplicades['div-mcm'] = (aplicades['div-mcm'] || 0) + 1;
    const [a, b] = [+dos[1], +dos[2]];
    if (!r.endsWith('= ' + (a * b / mcd(a, b))))
      errors.push(`${it.gen}/${it.llavor}: m.c.m. incorrecte`);
  }
  if (it.gen === 'arr-exacta') {
    aplicades['arr-exacta'] = (aplicades['arr-exacta'] || 0) + 1;
    const n = +(it.enunciat.match(/sqrt\{(\d+)\}/) || [])[1];
    if (r !== String(Math.sqrt(n))) errors.push(`${it.gen}/${it.llavor}: arrel incorrecta`);
  }
  if (it.gen === 'pol-diagonals') {
    aplicades['pol-diagonals'] = (aplicades['pol-diagonals'] || 0) + 1;
    const n = +(e.match(/\((\d+) costats\)/) || [])[1];
    if (!r.startsWith(String(n * (n - 3) / 2)))
      errors.push(`${it.gen}/${it.llavor}: diagonals incorrectes`);
  }
  if (it.gen === 'pol-angles') {
    aplicades['pol-angles'] = (aplicades['pol-angles'] || 0) + 1;
    const n = +(e.match(/\((\d+) costats\)/) || [])[1];
    if (!r.startsWith(String((n - 2) * 180)))
      errors.push(`${it.gen}/${it.llavor}: suma d'angles incorrecta`);
  }

  /* ---- 4t d'ESO · Aplicades -------------------------------------------- */
  const nums = t => (String(t).match(/-?\d+(?:\{,\}\d+)?/g) || []).map(decimal);
  const dols = t => (String(t).match(/\$(\d+)\$/g) || []).map(x => +x.slice(1, -1));
  // Expressió en x amb ^, producte implícit i parèntesis: `(x - 3)(x + 5)`, `2x^2 - 4x`.
  const poli = (expr, x) => {
    const js = expr.replace(/\\cdot/g, '*').replace(/\s+/g, '')
      .replace(/\^/g, '**').replace(/(\d|\))x/g, '$1*x').replace(/(\d|\))\(/g, '$1*(')
      .replace(/\)(?=\()/g, ')*').replace(/x\(/g, 'x*(').replace(/x/g, '(' + x + ')')
      .replace(/(\((?:[^()]|\([^()]*\))*\))\*\*(\d)/g, 'Math.pow($1,$2)');
    if (!/^[-+*/().\dMathpow,]+$/.test(js)) throw new Error('expressió inesperada: ' + expr);
    return Function('return (' + js + ');')();
  };
  const solucions = t => (t.match(/x = (-?\d+)/g) || []).map(q => +q.replace('x = ', ''));
  if (['eq2-x2k', 'eq2-parentesi', 'eq2-producte', 'eq2-incompleta', 'eq2-formula'].includes(it.gen)) {
    compta();
    const [esq, dre] = mat(it.enunciat).split('=');
    const xs = solucions(it.resposta.replace(/\$/g, ' '));
    if (xs.length !== 2 && !(it.gen === 'eq2-x2k' && xs.length === 2)) malament('no hi ha dues solucions');
    xs.forEach(x => { if (poli(esq, x) !== poli(dre, x)) malament(`x = ${x} no és solució`); });
    if (new Set(xs).size !== xs.length) malament('solucions repetides');
  }
  if (it.gen === 'eq2-discriminant') {
    compta();
    const [a, b, c] = (() => {
      const m = mat(it.enunciat).split('=')[0];
      const a = +((m.match(/^(\d*)x\^2/) || [])[1] || 1);
      const b = +((m.match(/([+-]) *(\d+)x(?! *\^)/) || []).slice(1, 3).join('') || 0);
      const c = +(m.replace(/^.*x\^2/, '').replace(/[+-] *\d+x/, '').replace(/\s+/g, '') || 0);
      return [a, b, c];
    })();
    const d = b * b - 4 * a * c;
    if (+(it.resposta.match(/Delta = (-?\d+)/) || [])[1] !== d) malament('discriminant incorrecte');
    const tipus = d > 0 ? 'dues' : d === 0 ? 'una' : 'cap';
    if (!new RegExp(tipus).test(it.resposta)) malament('nombre de solucions incorrecte');
  }
  if (it.gen === 'qua-vertex') {
    compta();
    const f = mat(it.enunciat.replace(/^.*y = /, '$')).replace(/\$/g, '');
    const [h, k] = nums(it.resposta.match(/\((.*)\)/)[1]);
    const y = x => poli(f.replace(/\.$/, ''), x);
    if (y(h) !== k) malament('el vèrtex no és a la paràbola');
    if (!(y(h - 1) - k === y(h + 1) - k && Math.sign(y(h + 1) - k) !== 0)) malament('no és el vèrtex (simetria)');
  }
  if (it.gen === 'qua-talls') {
    compta();
    const f = it.enunciat.match(/y = ([^$]*)\$/)[1];
    const [c0, p, q] = [nums(it.resposta.match(/OY\$: \$\(0, (-?\d+)\)/)[1])[0],
                        ...nums(it.resposta.match(/OX\$: \$\((-?\d+), 0\)\$ i \$\((-?\d+), 0\)/).slice(1, 3).join(' '))];
    if (poli(f, 0) !== c0 || poli(f, p) !== 0 || poli(f, q) !== 0) malament('punts de tall incorrectes');
  }
  if (it.gen === 'qua-valor') {
    compta();
    const f = it.enunciat.match(/y = ([^$]*)\$/)[1], x = +it.enunciat.match(/x = (-?\d+)/)[1];
    if (poli(f, x) !== +it.resposta.match(/-?\d+/)[0]) malament('valor de la funció incorrecte');
  }
  if (it.gen === 'pct-variacio') {
    compta();
    const [preu, p] = dols(it.enunciat.replace(/\\,\\%/g, ''));
    const nou = preu * (1 + (/augmenta/.test(e) ? 1 : -1) * p / 100);
    if (Math.abs(nou - decimal(mat(it.resposta))) > 1e-9) malament('preu nou incorrecte');
  }
  if (it.gen === 'pct-iva') {
    compta();
    const [base, p] = dols(it.enunciat.replace(/\\,\\%/g, ''));
    if (Math.abs(base * (1 + p / 100) - decimal(mat(it.resposta))) > 1e-9) malament('IVA incorrecte');
  }
  if (it.gen === 'pct-ponderada') {
    compta();
    const v = dols(it.enunciat.replace(/\\,\\%/g, ''));
    if (Math.abs((v[0] * v[2] + v[1] * v[3]) / 100 - decimal(mat(it.resposta))) > 1e-9) malament('mitjana ponderada incorrecta');
  }
  if (it.gen === 'pit-hipotenusa' || it.gen === 'pit-catet') {
    compta();
    const [a, b] = dols(it.enunciat), x = +mat(it.resposta);
    const ok = it.gen === 'pit-hipotenusa' ? a * a + b * b === x * x : a * a === b * b + x * x;
    if (!ok) malament('Pitàgores no es compleix');
  }
  if (it.gen === 'est-desv-mitjana') {
    compta();
    const xs = nums(mat(it.enunciat)), m = xs.reduce((a, b) => a + b, 0) / xs.length,
      dm = xs.reduce((a, b) => a + Math.abs(b - m), 0) / xs.length;
    const [rm, rd] = nums(it.resposta.replace(/[^\d,{}]+/g, ' ').trim().split(/\s+/).join(' '));
    if (rm !== m || rd !== dm) malament('mitjana o desviació mitjana incorrectes');
  }
  if (it.gen === 'pro-venn') {
    compta();
    const [t, a, b, c] = dols(it.enunciat), [n, d] = fraccio(it.resposta);
    if ((a + b - c) / t !== n / d) malament('probabilitat de la unió incorrecta');
  }
  if (it.gen === 'pro-composta') {
    compta();
    const [v, b] = dols(it.enunciat), [n, d] = fraccio(it.resposta);
    if (Math.abs(v * (v - 1) / ((v + b) * (v + b - 1)) - n / d) > 1e-9) malament('probabilitat composta incorrecta');
  }
  if (it.gen === 'exp-context') {
    compta();
    const [n0, t] = dols(it.enunciat), f = /duplica/.test(e) ? 2 : 3;
    if (n0 * f ** t !== +mat(it.resposta).replace(/\\,/g, '')) malament('població incorrecta');
  }
  /* ---- 4t d'ESO · Acadèmiques ------------------------------------------ */
  const prim = t => +((String(t).match(/-?\d+/) || [])[0]);
  if (it.gen === 'trig-raons') {
    compta();
    const [op, ad, h] = (it.enunciat.match(/\$(\d+)\$/g) || []).map(x => +x.slice(1, -1));
    if (op * op + ad * ad !== h * h) malament('el triangle no és rectangle');
    const fr = [...it.resposta.matchAll(/\\dfrac\{(\d+)\}\{(\d+)\}/g)].map(q => q[1] / q[2]);
    const bons = [op / h, ad / h, op / ad];
    if (fr.length !== 3 || fr.some((v, i) => Math.abs(v - bons[i]) > 1e-9)) malament('raons incorrectes');
  }
  if (it.gen === 'trig-cosinus') {
    compta();
    const [a, b] = dols(it.enunciat), c = +(it.enunciat.match(/(\d+)\^\\circ/) || [])[1], x = prim(it.resposta);
    const x2 = a * a + b * b - 2 * a * b * (c === 60 ? 0.5 : -0.5);
    if (Math.abs(x * x - x2) > 1e-9) malament('teorema del cosinus incorrecte');
  }
  if (it.gen === 'trig-sinus') {
    compta();
    const [a] = dols(it.enunciat), val = decimal((mat(it.resposta).match(/approx *(\d+(?:\{,\}\d+)?)/) || [])[1] || 'NaN');
    if (Math.abs(val - a * Math.SQRT2) > 0.006) malament('teorema del sinus incorrecte');
  }
  if (it.gen === 'trig-catet') {
    compta();
    const [h] = dols(it.enunciat);
    if (prim(it.resposta) * 2 !== h) malament('catet incorrecte');
  }
  if (it.gen === 'com-variacions' || it.gen === 'com-vr' || it.gen === 'com-combinacions') {
    compta();
    const [n, k] = dols(it.enunciat), x = prim(mat(it.resposta).replace(/\\,/g, ''));
    const f = q => q <= 1 ? 1 : q * f(q - 1);
    // a `com-vr` l'enunciat diu primer els caràcters (k) i després els símbols (n)
    const esperat = it.gen === 'com-variacions' ? f(n) / f(n - k) : it.gen === 'com-vr' ? Math.pow(k, n)
      : f(k) / (f(n) * f(k - n)); // combinacions: l'enunciat diu primer triar (n) i després el grup (k)
    if (x !== esperat) malament('recompte incorrecte');
  }
  if (it.gen === 'log-def') {
    compta();
    const m = mat(it.enunciat), b = +(m.match(/log_\{?(\d+)\}?/) || [])[1];
    if (/=/.test(m)) {
      const n = +m.split('=')[1], x = +(mat(it.resposta).match(/x *= *(\d+)/) || [])[1];
      if (Math.pow(b, n) !== x) malament('logaritme incorrecte');
    } else {
      const N = +m.replace(/^.*log_\{?\d+\}? */, '');
      if (Math.pow(b, prim(it.resposta)) !== N) malament('logaritme incorrecte');
    }
  }
  if (it.gen === 'est-variancia') {
    compta();
    const xs = nums(mat(it.enunciat)), n = xs.length, m = xs.reduce((a, b) => a + b, 0) / n,
      v = xs.reduce((a, b) => a + (b - m) * (b - m), 0) / n, [rm, rv, rs] = nums(it.resposta.replace(/[^\d,{}]+/g, ' ').trim().split(/\s+/).join(' '));
    if (rm !== m || rv !== v || rs * rs !== v) malament('mitjana, variància o desviació incorrectes');
  }
}

function comprova() {
  const errors = [];
  let variants = 0;
  /* Les comprovacions aritmètiques depenen de la redacció de l'enunciat: si
     algú la canvia, deixarien de comprovar res en silenci. Es compta quantes
     vegades s'han pogut aplicar i es reclama si alguna ha deixat de saltar. */
  const aplicades = {};

  for (const g of GEN.llista) {
    for (let s = 0; s < MOSTRA; s++) {
      let it;
      try {
        it = GEN.crea(g.id, 'c' + s);
      } catch (err) {
        errors.push(`${g.id}: peta amb la llavor c${s} — ${err.message}`);
        break;
      }
      variants++;
      if (!it.enunciat && !it.figura) errors.push(`${g.id}/c${s}: sense enunciat ni figura`);
      if (!it.resposta) errors.push(`${g.id}/c${s}: sense resposta`);
      if (!it.passos.length) errors.push(`${g.id}/c${s}: sense passos`);
      if (!it.sabers.length) errors.push(`${g.id}: sense cap saber`);
      const text = it.cap + it.enunciat + it.resposta + it.passos.join('');
      if ((text.match(/\$/g) || []).length % 2)
        errors.push(`${g.id}/c${s}: dòlars de LaTeX desaparellats`);
      aritmetica(it, errors, aplicades);
    }
  }

  ['div-mcd', 'div-mcm', 'arr-exacta', 'pol-diagonals', 'pol-angles',
   'equ-un-pas', 'equ-dos-passos', 'equ-dues-bandes', 'equ-parentesi', 'alg-comprova',
   'fd-a-decimal', 'fd-a-fraccio', 'pro-regla-tres', 'are-basica', 'vol-cossos',
   'eq2-x2k', 'eq2-parentesi', 'eq2-producte', 'eq2-incompleta', 'eq2-formula',
   'eq2-discriminant', 'qua-vertex', 'qua-talls', 'qua-valor', 'pct-variacio',
   'pct-iva', 'pct-ponderada', 'pit-hipotenusa', 'pit-catet', 'est-desv-mitjana',
   'pro-venn', 'pro-composta', 'exp-context',
   'trig-raons', 'trig-cosinus', 'trig-sinus', 'trig-catet', 'com-variacions', 'com-vr',
   'com-combinacions', 'log-def', 'est-variancia']
    .forEach(g => {
      if (!aplicades[g]) {
        errors.push(`${g}: la comprovació aritmètica no s'ha pogut aplicar ` +
                    'ni una sola vegada. Ha canviat la redacció de l\'enunciat?');
      }
    });

  const cat = catalog();
  console.log(`Generadors: ${GEN.llista.length}`);
  console.log(`Variants provades: ${variants}`);
  console.log(`Ítems al catàleg: ${cat.length}`);

  const perSaber = {};
  cat.forEach(it => it.sabers.forEach(s => { perSaber[s] = (perSaber[s] || 0) + 1; }));
  Object.keys(perSaber).sort().forEach(s => {
    console.log(`  ${s.padEnd(26)} ${String(perSaber[s]).padStart(3)}`);
  });

  if (errors.length) {
    console.log('\nERRORS:');
    errors.slice(0, 30).forEach(e => console.log('  -', e));
    if (errors.length > 30) console.log(`  … i ${errors.length - 30} més`);
  } else {
    console.log('\nCap error.');
  }
  return !errors.length;
}

/* ------------------------------------------------------------------ main */
function main() {
if (process.argv.includes('--cataleg')) {
  fs.writeSync(1, JSON.stringify(catalog()));
  return;
}

const iMostra = process.argv.indexOf('--mostra');
if (iMostra >= 0) {
  // Variants en cru per a compila.py, que és qui en mesura el nivell.
  const n = parseInt(process.argv[iMostra + 1], 10) || 100;
  const out = [];
  for (const g of GEN.llista) {
    for (let s = 0; s < n; s++) out.push(GEN.crea(g.id, 'c' + s));
  }
  // Escriptura síncrona: amb `process.stdout.write` seguit de `process.exit`,
  // Node talla la sortida quan va a una canonada i el JSON arriba a mitges.
  fs.writeSync(1, JSON.stringify(out));
  return;
}

// No escriu cap fitxer: el catàleg va per stdout amb `--cataleg` i és
// `compila.py` qui el consumeix. Un JSON intermedi al repositori només
// seria una còpia que es quedaria vella.
process.exitCode = comprova() ? 0 : 1;
}

main();
