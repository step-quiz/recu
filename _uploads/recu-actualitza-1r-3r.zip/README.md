# Prova de recuperació — Matemàtiques 1r, 2n, 3r i 4t d'ESO (Aplicades i Acadèmiques)

Lloc estàtic per muntar l'examen global de recuperació d'un alumne que arrossega
les matemàtiques d'un curs anterior (3r que recupera 2n, 4t que recupera 3r…). Cursos: 1r, 2n, 3r, **4t d'ESO · Aplicades** i **4t d'ESO · Acadèmiques**. HTML, CSS i JavaScript vainilla: cap build,
cap servidor, cap dependència externa. **Obre `index.html` amb doble clic.**

Genera dos documents des d'una sola selecció de continguts:

| Document | Per a qui | Què porta |
|---|---|---|
| **Prova** | l'alumne | enunciats numerats, punts, i espai quadriculat per respondre |
| **Full de correcció** | el professor | una taula per pregunta, amb un espai entre taules: «Enunciat», l'enunciat copiat i numerat com a la prova, «Solució \| Passos» i, a sota, la solució (30 %) i els passos a), b), c)… (70 %); en una pàgina a part, la graella de puntuació |

---

## Com es fa servir

> **La prova és un document, no una consulta.** Marcar un contingut hi
> **afegeix** una pregunta; desmarcar-lo en treu les seves; moure el nombre de
> preguntes n'afegeix o en treu; canviar l'ordre només reordena. Res d'això
> toca les preguntes que ja has triat. L'única cosa que refà la prova de zero
> és el que ho demana explícitament: la drecera `Ctrl+G`, canviar el **nivell**
> i canviar el **criteri de repartiment**. I fins i tot allà se salven les
> preguntes pròpies i les marcades amb ☆.

1. **Marca els continguts** a la columna de l'esquerra. És el *Repartiment de
   continguts ESO 2025-26* del departament, tal com està escrit: curs → sentit →
   saber, amb una excepció: *Millora de la comprensió lectora*, que al document
   és el primer sentit de cada curs, a la columna surt l'últim. Clicant el
   títol del curs es marquen o desmarquen tots de cop.
2. **Ajusta la prova** a la dreta. A dalt hi ha el que es toca a cada prova:
   quantes preguntes i quin nivell. A sota, plegat: la llista de *Preguntes*,
   *Format del full*, *Preferències* i, al final de tot, *Punts, temps i
   ordre*. Cada secció plegada diu al títol què hi tens triat (per exemple
   «38 mm · quadrícula» o «10 preguntes»), o sigui que no cal obrir-la per
   saber-ho. El navegador recorda quines seccions tens obertes, menys la de
   *Preguntes*, que surt sempre plegada: el full ja ensenya les preguntes, i
   clicant-ne una al full la llista es desplega sola. Els avisos («la prova
   suma 11 punts i no 10»…) surten a sobre de la llista, fora del plegable.
3. **Revisa el full** al centre. El que hi veus és exactament el que sortirà per
   la impressora; no hi ha una segona maquetació. **La capçalera s'escriu
   damunt del mateix full**: clica el centre, el títol, el subtítol, el nom,
   el grup o les instruccions i escriu-hi (Retorn acaba el camp; a les
   instruccions fa línia nova). Clicant la data s'obre el calendari. Els camps
   buits mostren una pista en gris que no s'imprimeix. El subtítol, si el
   deixes en blanc, torna a ser l'automàtic («Continguts de 2n d'ESO»).
4. **Imprimeix.** El botó de dalt diu *Imprimeix la prova* o *Imprimeix la
   correcció*, segons la pestanya que tinguis oberta. Al diàleg del navegador,
   desmarca *Capçaleres i peus de pàgina* i deixa els marges *Per defecte*: els marges reals els posa `@page`.
   «Desa com a PDF» dona el PDF.

**Per guardar una prova**, desa l'adreça de la pàgina (a les adreces d'interès
del navegador, o copiant-la): porta la prova sencera, amb les preguntes, els
punts, el format del full i la capçalera, **nom de l'alumne inclòs** (tingues-ho
present abans de passar l'enllaç a ningú).

**Desa com a valors inicials** (a *Preferències*) desa al navegador com vols trobar l'eina cada
vegada: continguts marcats, nivell, criteri de punts, format del full i
capçalera. No s'hi desen el nom de l'alumne, el grup, la data ni el
codi de la tria, perquè aquests han de començar de zero cada cop.

Cada prova té un **codi de cinc caràcters**, que no surt enlloc a la vista (ni
al panell ni al peu dels fulls, que no en porten): el guarda l'adreça de la
pàgina. Mateix codi, mateixa prova, sempre, així que pots desar l'enllaç i
recuperar l'examen mesos després. Per fer un altre model del mateix examen:
prem `Ctrl+G` (ja no hi ha botó «Altres preguntes» al panell) i torna a imprimir.

Les instruccions per a l'alumne comencen amb només «Instruccions: »: clica-hi
damunt del full i escriu-hi les teves. Si no hi escrius res més, la caixa es veu
a la pantalla però no s'imprimeix.

**Ctrl + G** refà la prova amb unes altres preguntes (conserva les ☆ i les
pròpies). No té botó; ho recorda una línia a *Preferències*.

### Els controls que no són obvis

**Valors per defecte de *Punts, temps i ordre*.** Gairebé sempre es fan
servir tal com venen, i per això la secció és l'última del panell:

| Paràmetre | Per defecte | Què vol dir | Altres opcions |
|---|---|---|---|
| *Els punts es reparteixen* | **Igual** | totes les preguntes valen el mateix | *Per nivell* (les de nivell 2 i 3 valen més), *Per hores* (valen més les dels continguts amb més hores) |
| *Ordre de les preguntes* | **De fàcil a difícil** | per nivell; a igual nivell, en l'ordre del currículum (mai a l'atzar) | *Del currículum*, *Barrejat* |
| *Reparteix les preguntes segons* | **Igual** | el mateix nombre de preguntes per a cada contingut marcat | *Hores* (més preguntes als continguts amb més hores), *Banc* (més als que tenen més preguntes al banc) |

Si escrius a mà els punts d'una pregunta, es queden fixos i la resta es
reparteix el que sobra. Canviar l'ordre només reordena; canviar el criteri de
repartiment refà la prova (conservant les ★ i les pròpies).

**El zoom del full.** El full fa sempre 210 mm d'ample, també en un portàtil on
no hi cap: és l'única manera que la pantalla parteixi les línies igual que el
paper i que el comptador de pàgines encerti. Per defecte s'escala perquè hi
càpiga sencer d'ample (a 1366 px, un 93 %): és l'opció **Ajustat** del
selector *Zoom*. Si hi tries un
altre valor (50, 75, 100 o 125 %), mana el teu fins que hi tornis a posar
*Ajustat*.

Fins ara no era així: a les pantalles de 1280–1440 px el full s'encongia
(fins a 592 px en lloc de 794), el text es partia en més línies que en paper i
el que es veia deixava de ser el que s'imprimia.

**Els cursos es pleguen.** En obrir l'eina tots surten plegats, i un curs es
desplega sol quan hi marques un contingut (o «Tot el curs»): qui recupera 2n no
ha de passar per damunt dels divuit continguts de 1r. Clicant el nom del curs
(«▸ 1r d'ESO») el plegues o el desplegues a mà, i el navegador ho recorda fins
que hi tornis a marcar un contingut. El comptador «3 / 18» diu quants n'hi ha de
marcats encara que estigui plegat. Una cerca desplega el que troba.

**Una sola barra a dalt**: el títol, les pestanyes *Prova | Correcció*, el
*Zoom* i el botó d'imprimir. En un portàtil de 14" el que falta és alçada, i les
dues franges d'abans se'n menjaven 100 px.

**Aparença.** La interfície segueix el mode clar o fosc del sistema operatiu;
no hi ha cap botó per canviar-lo. El full no canvia mai de color: és paper.

**Apartats (6a, 6b).** Si dues o més preguntes SEGUIDES són del mateix
exercici i tenen la mateixa consigna, surten com una sola pregunta amb apartats:
«6. Resol aquestes equacions.» i a sota a), b), c), cadascun amb el seu espai de
resposta, els seus punts i les seves icones al marge. La consigna s'imprimeix
un sol cop. La clau i la graella de correcció les numeren 6a, 6b, 6c, i al
panell de la dreta cada pregunta porta l'etiqueta que té al full quan no
coincideix amb la posició. Passa amb els apartats del banc de repàs (f5-75a,
f5-75b…) i amb les variants d'un mateix generador; dos problemes de
*Comprensió lectora*, que no tenen consigna comuna, no s'agrupen. Per tenir-les
separades, desmarca *Agrupa apartats* a la secció *Format del full*.

**Temps estimat.** A dalt del panell, al costat de «La prova», surt quant
tardarà l'alumne a fer la prova contra la *Durada (minuts)* que té (per defecte
55, una hora de classe; es canvia a *Punts, temps i ordre*): en verd si hi cap, en ambre
si probablement no. Compta 4 minuts per pregunta de nivell 1, 6 de nivell 2 i 9
de nivell 3 (les pròpies, com a nivell 2). No surt dels passos de la resolució:
mesurats, els tres nivells en tenen de mitjana gairebé els mateixos (1,8, 2,0 i
2,1); el que els separa és la lectura i la mena de nombres, que és justament el
que mesura el nivell. És una estimació: si amb els teus grups les proves surten
sistemàticament curtes o llargues, els tres valors són a `MINUTS_NIVELL`, a
`assets/js/composa.js`. Una prova de mínims de 10 preguntes surt a uns 40
minuts. La durada es desa amb *Desa com a valors inicials* i a l'adreça.

**El nivell d'una pregunta concreta.** Al panell de la dreta, clicant una
pregunta, s'obre amb un selector de nivell. Per defecte diu «General (1)»:
segueix la barreja del control de dalt. Si hi tries 1, 2 o 3, la
clava a aquell nivell i s'hi queda —«‹» i «⇄ Una altra» només oferiran preguntes
d'aquell nivell— fins que la tornis a posar a «general».

Serveix per al cas que ho va motivar: una prova de mínims amb un parell de
preguntes més exigents, sense haver de tocar el nivell general.

Els nivells que un contingut no té surten **desactivats**: només 49 dels 76
en tenen els tres. Angles de 1r d'ESO, per exemple, té 25 preguntes i totes de
nivell 1.

**Nivell de les preguntes.** No és el `dif` del banc de `repas`, que està
calibrat per a repàs a l'entrada de batxillerat. Aquí es recalcula a
`tools/compila.py` mesurant les dues coses que bloquegen un alumne amb
mancances grosses:

- **quant ha de llegir** — caràcters de l'encapçalament *i* de l'enunciat, i
  quantes dades ha de processar (una llista de 50 valors és lectura pura);
- **com són els nombres** — el més gran de l'enunciat, el més gran de la
  solució, el denominador més gran del resultat, si hi ha una arrel no exacta
  *donada a l'enunciat*, i si hi ha fraccions a l'enunciat quan el tema no són
  les fraccions.

L'última també ve del departament: `x/5 = 3` es resol en un pas, però una
equació amb denominadors no és de mínims per a qui ve de suspendre tot el curs.
Les fraccions només compten com a càrrega fora dels blocs on la fracció és el
contingut que s'avalua (la llista és `BLOCS_DE_FRACCIONS`, a
`tools/mapa_curricular.py`).

L'última distinció importa: `\sqrt{89}` com a **resultat** de la diagonal d'un
rectangle de 5×8 és normal i no penalitza; `\sqrt{164}` com a **alçada donada**
d'un trapezi és artificial i el treu de nivell 1. Els casos concrets que van
fixar aquesta calibració estan a `tools/tests.js`, a la llista `VEREDICTES`,
amb el motiu escrit al costat: si algú retoca la fórmula i torna a colar la
descomposició factorial de 3850 al nivell mínim, salta una prova.

| Perfil | Per a què serveix | Nivell mitjà mesurat (2n d'ESO) |
|---|---|---|
| `Mínims` | comprovar si ha assolit els mínims | 1,01 |
| `Equilibrat` | una recuperació normal | 1,25 |
| `Exigent` | pujar nota | 1,84 |

(Mitjana de 300 proves de 20 preguntes amb tot 2n d'ESO marcat.)

`Mínims` i `Equilibrat` viuen tots dos al nivell 1 a propòsit: aquests alumnes
no van aprovar les matemàtiques en cap moment del curs anterior.

**Reparteix les preguntes segons.** `Hores` fa servir les hores de classe del
document del departament: si Equacions són 9 h i Percentatges 4 h, la prova
respecta aquesta proporció. `Banc` reparteix segons quantes preguntes hi ha
disponibles. `Igual` dona el mateix nombre a cada contingut.

**Dos passamans que no es poden apagar.** Un ítem pot declarar que necessita
l'encapçalament (`capCal`: l'enunciat és una dada solta, com «$3850$») o que
necessita la figura (`figuraCal`: la pregunta *és* el dibuix). Aquests dos
elements es continuen imprimint encara que el professor apagui les opcions
corresponents, perquè si no el full sortiria amb preguntes que no es poden
respondre. Els declara el generador; per als 811 ítems de `repas` els dedueix
el compilador. Una comprovació de `tests.js` recorre les quatre combinacions
dels dos interruptors i verifica que cap ítem no es quedi buit amb cap.

**Les accions de cada pregunta.** Al panell de la dreta, cada pregunta és
una fila plegada que només diu què és, de quin contingut i quant val.
Clicant-la (al panell o al mateix full) s'obre, es ressalta al full i
mostra tot el que s'hi pot fer: nivell, punts i aquests botons. Per plegar-la,
el botó `▴` de la fila, tornar-la a clicar o la tecla `Esc`.

| | Què fa | Al marge del full? |
|---|---|---|
| `‹` `⇄` | la pregunta anterior i la següent d'aquest contingut (dues fletxes que es creuen: canvia-la) | `⇄` sí |
| dau | uns altres nombres, **la mateixa pregunta** (material propi) | sí |
| `+` | **un apartat més**, a sota (a, b, c…): amb material propi, la mateixa pregunta amb uns altres nombres; amb el banc de `repas`, el següent apartat del mateix exercici | sí |
| `☆` | la fixa perquè sobrevisqui a `Ctrl+G` i als canvis de nivell o de repartiment | no |
| `↑ ↓` | la mou una posició | no |
| `✕` | la treu de la prova | sí |

Al marge esquerre del full només hi ha les que es fan mirant la pregunta
(`⇄`, dau, `+`, `✕`); abans n'hi havia set a cada pregunta i eren més soroll
que ajuda. Són icones dibuixades en SVG (`ICONA`, a `assets/js/full.js`) i
no caràcters: les fletxes circulars d'abans (⟳ ↻) no deien què feien.

**El `+` fa apartats.** No substitueix la pregunta: n'afegeix una altra variant
just a sota (o a sota de l'últim apartat del grup), i com que és el mateix
exercici amb la mateixa consigna, el full les agrupa soles: «2. Fes la
descomposició en factors primers. a) 24 b) 18 c) 100». Cada apartat té el seu
espai, els seus punts i les seves icones, i compta com una pregunta més.

Amb les preguntes del banc de `repas`, que són text fix i no poden canviar de
nombres, el `+` afegeix el següent apartat **del mateix exercici del banc** que
no sigui a la prova (f1-24a → f1-24b → f1-24c…), del mateix nivell si n'hi ha.
473 de les 592 preguntes de `repas` tenen germans així. Quan s'han acabat, el
`+` desapareix. Tampoc no surt on no hi ha consigna, que és el que uneix els
apartats (*Comprensió lectora*, per exemple). Amb *Agrupa apartats*
desmarcat, les variants surten com a preguntes separades.

**`‹` i `⇄` no tiren un dau cada cop.** L'atzar decideix una sola vegada en
quin ordre sortiran totes les preguntes del contingut, i els dos botons
recorren aquesta llista endavant i endarrere. Abans de repetir-ne cap, les
hauràs vistes totes: en un contingut de 31 preguntes calen 31 clics per
tornar a veure la primera. Amb una tria a l'atzar cada clic, el que sortia
era A, B, B, A, C, B, C — tres preguntes vistes de trenta-una.

Quan el contingut té material propi, la volta no s'acaba mai: en arribar al
final s'hi afegeixen variants noves en comptes de tornar a començar.

**La posició de cada pregunta és un camp** al panell de la dreta: escriure-hi
un número la porta allà d'una passa. Les fletxes `↑ ↓` són per a l'ajust fi;
per anar de la catorzena a la tercera no cal fer onze clics.

**Les preguntes noves s'insereixen al seu lloc**, no al final: si afegeixes un
contingut de 1r d'ESO a una prova de 2n, la pregunta va on li toca segons el
currículum. Amb l'ordre «Barrejat» o «De fàcil a difícil» s'afegeix al final,
perquè allà la posició curricular no vol dir res.

El dau només pot existir on la pregunta ve d'un generador. Les 878 preguntes que
venen del banc de `repas` són text ja escrit i no es poden reparametritzar; les
766 pròpies sí, i el pou és infinit. 59 dels setanta-sis sabers tenen
material propi, i a aquests, a la pràctica, no se'ls acaben mai les preguntes. Per decidir si una pregunta et va bé, l'has d'estar mirant.

El carril dels botons queda dins de la caixa de la pregunta (un `padding-left`
amb un `margin-left` negatiu igual), de manera que el contingut no es mou i
l'alçada tampoc —que és el que mesura el comptador de pàgines— però passar-hi
el ratolí ja compta com a estar sobre la pregunta. I la barra inactiva porta
`pointer-events:none`: amb l'espai de resposta a 0 la barra fa 133 px i la
pregunta 21, o sigui que sobresurt, i un element amb `opacity:0` segueix rebent
clics. `tools/prova.js` comprova tots els botons amb l'espai més atapeït.

Les icones fan 22 px, són gris fosc i van separades 15 px. Amb el ratolí a
sobre creixen un 20 %, amb vora blau fosc i fons blau clar: a 17 px, en gris
clar i enganxades gairebé no es veien.

Les instruccions per defecte són només «Instruccions: ». Una adreça o uns
valors inicials desats amb les instruccions llargues d'abans («Resol cada
exercici a l'espai…») es llegeixen amb les noves; si les havies retocat, es
conserven tal com les vas deixar.

En pantalla estreta el full es dibuixa a escala reduïda i uns botons de 22 px en
quedarien 12, o sigui que allà les icones del marge s'amaguen i les accions es
fan des del panell d'ajustos, obrint la pregunta.

**El «− 2 +» de cada contingut marcat** diu quantes preguntes en té la prova
i n'afegeix o en treu d'una en una. És el que cal quan la recuperació s'ha de
construir sobre els criteris concrets que l'alumne no va assolir, i no sobre un
total global. Als continguts no marcats no surt: marcar la casella ja hi posa
una pregunta.

**El nombre de pàgines** surt al costat del botó d'imprimir (només a la prova, i
només si té preguntes), amb un «≈»
que no és decoratiu: es calcula simulant la paginació —cada pregunta és un
bloc que no es parteix— i, contrastat contra 126 PDF reals, encerta el
96-98 % de les vegades. Quan falla és sempre una pàgina de menys. Afinar-ho
més voldria paginar de debò, i per a un número que serveix per decidir si val
la pena imprimir no compensa.

**Els punts es reparteixen.** `Igual` dona el mateix a totes; `Per nivell` fa
que una de nivell 3 valgui el doble que una d'1; `Per hores` segueix les hores
del contingut al currículum. I es pot **escriure el valor de qualsevol pregunta
a mà**: queda fixat (es marca en blau) i la resta es reparteixen el que sobra.

**+ Pregunta pròpia.** Escriu-hi l'enunciat i la solució; el LaTeX va entre
dòlars (`$x^2+1$`). Serveix per als continguts que no tenen banc (vegeu més
avall). Les preguntes pròpies queden fixades i no es perden en regenerar.

---

## D'on surt el contingut

Res del que hi ha aquí és nou: això és una capa d'índex sobre material que ja
tenies.

```
El .docx del departament  →  l'estructura: 76 sabers, amb les seves hores
repas (banc de 1029 items)→  878 preguntes, amb les seves solucions
assets/js/generadors.js   →  766 preguntes pròpies, i infinites variants
llibre (296 PDFs)         →  referències per saber (al mapa; ara no es mostren)
Mates amb Bogdan (12 PDF) →  material d'ampliació (al mapa; ara no es mostra)
```

Les referències al llibre i a Mates amb Bogdan les feia servir el *pla de repàs*,
que s'ha tret de l'eina. `compila.py` les continua escrivint a `mapa.js`.

Són **1644 preguntes** al catàleg. Un cop compilades, l'eina no distingeix les
d'un origen de les de l'altre.
Els enunciats, les figures SVG i les resolucions són literalment els de `repas`;
el que canvia és que aquí es fan servir com a **resposta oberta**, sense les
quatre opcions: l'alumne escriu el procés.

### Cobertura per curs

**2n d'ESO** queda ben cobert. Els blocs amb més fons són Variables
estadístiques (64), Equacions de 1r grau (55), Divisibilitat (50), Fraccions
(41), Potències (35) i Pitàgores (31).

**Ara mateix no hi ha cap forat**: els 76 sabers del currículum tenen preguntes,
i tots en tenen almenys una de nivell 1. Fins fa poc no era així; el que ho ha
tancat és `assets/js/generadors.js` (vegeu més avall). Si algun dia se'n torna a
obrir un, els sabers sense preguntes no es llisten i al peu del curs hi surt una
línia que en diu el nombre.

Els forats que hi havia al banc de `repas` i que ara cobreix el material propi:

| Saber | Curs | Hores |
|---|---|---|
| Comprensió lectora matemàtica | 1r, 2n, 3r | 12 / 9 / 12 |
| Arrel quadrada | 1r | 3 |
| Elements geomètrics al pla | 1r | 3 |
| Magnituds i unitats | 1r | 2 |
| Llenguatge algebraic | 1r | 3 |
| Vocabulari geomètric | 2n | 2 |
| Moviments al pla | 3r | 9 |

I els que en tenien massa poc, o cap de prou curt: Angles (1 ítem), Perímetres
(2), Polígons (3), Divisibilitat, Nombres decimals, Gràfics i taules,
Circumferència i cercle, Semblança.

### El material propi: `assets/js/generadors.js`

Cent onze generadors deterministes que produeixen preguntes amb solució i
passos, i figures SVG on calen. El criteri és el que va sortir de revisar
proves impreses:

- **nombres petits** — cap descomposició de 3850, cap potència que doni −759375;
- **enunciats curts** — el que bloqueja aquest alumnat és llegir i decidir;
- **resultats nets** — cap arrel no exacta donada com a dada.

**Per què són en JavaScript i no en Python.** Perquè el navegador els ha de
poder executar: és el que fa que el dau pugui donar uns altres nombres sense
sortir del tipus de pregunta. Si el compilador en tingués una còpia en Python,
hi hauria dues versions de cada exercici i acabarien divergint. Per això
`tools/compila.py` executa aquest mateix fitxer amb Node
(`tools/genera.js --cataleg`) per omplir el catàleg de `banc.js`.

**Això vol dir que compilar necessita Node.** Fer servir l'eina, no.

Es comprova sol:

```sh
node tools/genera.js --comprova
```

Verifica sobre 200 tirades de cada generador que cap peti, que sempre tornin
enunciat (o figura), resposta i passos, que els dòlars de LaTeX estiguin
aparellats, i recalcula els m.c.d., els m.c.m., les arrels i les diagonals per
contrastar-los amb la resposta escrita.

**El nivell no es mesura allà.** El mesurador viu a `tools/compila.py` i és
l'únic que hi ha. Cada generador declara el nivell que tenen totes les seves
variants, i en compilar es generen 200 variants de cadascun i es comprova que
sigui cert. Si un generador no és estable, **la compilació s'atura amb error**
i diu quin és i quins nivells li surten: no es genera cap `banc.js` que
prometi un nivell que no és cert. Va atrapar tres casos reals mentre s'escrivia:

- `arr-entre` («entre quins enters és $\sqrt{50}$») el penalitzava l'arrel no
  exacta de l'enunciat, que aquí és l'exercici mateix i no un defecte: exempció
  a `BLOCS_D_ARRELS`.
- `mag-puja` sortia a nivell 1 o 2 segons si el factor de conversió era 10 o
  1000. El factor apareix als passos («$1$ m $= 1000$ mm») i no és cap càrrega
  de càlcul, així que el mesurador va passar a mirar la mida de la **resposta** i
  no la de tot el desenvolupament.
- `mag-superficie` barrejava passar de cm² a mm² amb passar de m² a cm². Són
  exercicis de dificultat diferent —un resultat de cinc xifres no és el mateix—
  i ara són dos generadors, `mag-superficie` i `mag-superficie-gran`.

### Ítems que s'exclouen a propòsit

`tools/mapa_curricular.py` porta dues llistes de filtre, totes dues documentades
al fitxer:

- **`VETOS`** — 16 dels 26 exercicis de divisibilitat porten nombres negatius
  («descomposició factorial de −432», «m.c.d. de 45 i −27»). A 1r i 2n la
  divisibilitat es treballa dins dels naturals, i el signe només afegeix soroll.
  A 3r no es filtren.
- **`EXCLOSOS`** — tres enunciats es referien a unes opcions que aquí no
  s'imprimeixen («quin d'aquests valors pot tenir *x*?») i sense la llista no es
  poden respondre.

### El material de nivell 1 de cada saber

Tots els sabers en tenen almenys sis de nivell 1 menys un (*Cossos de
revolució*, amb cinc), i l'informe de `compila.py` marca els que es quedin
sense cap («el perfil mínims no els podrà fer servir»). Onze generadors
s'han escrit expressament per als continguts que en tenien menys:

| Generador | Saber | Nivell 1 abans → ara |
|---|---|---|
| `equ-un-pas`, `equ-dos-passos`, `equ-dues-bandes`, `equ-parentesi` | Equació de 1r grau (2n i 3r) | 7 → 31 |
| `alg-comprova`, i `alg-frase` / `alg-context` també per a 3r | Llenguatge algebraic (2n i 3r) | 3r: 1 → 19 · 2n: 13 → 19 |
| `fd-a-decimal`, `fd-a-fraccio` | Fraccions i decimals (1r) | 2 → 14 |
| `pro-regla-tres` | Proporcionalitat (2n) | 5 → 11 |
| `pc-quadrant` | El pla cartesià (2n) | 5 → 11 |
| `are-basica` | Càlcul d'àrees (1r) i Perímetres i àrees (2n) | 5 → 11 · 8 → 14 |
| `vol-cossos` | Àrees i volums a l'espai (2n) | 4 → 10 |

Les equacions són les que un alumne que ve de suspendre ha de saber fer abans
de res: aïllar la *x* amb nombres petits i solucions enteres, amb els passos que
s'escriurien a la pissarra. Les de repàs, en canvi, porten gairebé totes
denominadors o són problemes llargs. `genera.js --comprova` verifica
l'aritmètica de tots: substitueix la solució a l'equació, recalcula el decimal,
la regla de tres, l'àrea i el volum.

---

## Estructura

    index.html                  l'eina sencera (una sola pàgina)
    assets/css/eina.css         pantalla
    assets/css/imprimir.css     @page, marges A4 i salts de pàgina
    assets/js/atzar.js          atzar amb llavor: exàmens reproduïbles
    assets/js/composa.js        repartiment i tria de preguntes (funció pura)
    assets/js/full.js           construcció dels dos documents imprimibles (prova i correcció)
    assets/js/app.js            controlador: arbre, estat i render
    assets/js/banc.js           GENERAT — els 1644 ítems amb solució
    assets/js/mapa.js           GENERAT — currículum, cobertura i índex del llibre
    assets/lib/katex/           KaTeX en local

    assets/js/generadors.js     els 131 generadors del material propi

    tools/mapa_curricular.py    el mapa saber → fonts. AQUÍ es toca el currículum
    tools/compila.py            genera banc.js i mapa.js (necessita Node)
    tools/genera.js             executa els generadors: catàleg i verificacions
    tools/tests.js              proves de la lògica (node, sense dependències)
    tools/prova.js              prova amb navegador (necessita Playwright)
    tools/prova_compilacio.py   banc.js i mapa.js al dia, compilació determinista
    tools/llibre_des_de_tex.py  instantània dels títols d'un llibre d'Overleaf (4t Aplicades i Acadèmiques)
    tools/llibre/               instantànies: 4eso-apl.json, 4eso.json

    .github/workflows/tests.yml         les quatre proves, a cada push i PR
    .github/workflows/unzip-upload.yml  descomprimeix els ZIP de _uploads/

### Per què fitxers `.js` i no `.json`

Perquè l'eina ha de funcionar amb doble clic. Un `fetch()` d'un JSON des de
`file://` el bloqueja el navegador; `banc.js` i `mapa.js` assignen a `window` i
es carreguen amb un `<script>`, que sí que funciona. És la mateixa decisió que ja
hi ha a `repas` amb `data/fullN.js`.

### Per què KaTeX en local i cap tipografia web

Perquè el filtre del centre bloqueja els CDN, i perquè 87 % dels enunciats porten
LaTeX: sense KaTeX l'examen surt imprès amb `$3x-4x^2$` en cru. La carpeta
`assets/lib/katex/` ha de viatjar sempre amb `index.html`.

---

## 4t d'ESO · Aplicades

És el quart curs de l'eina (`id` `4eso-apl`, sabers `4eso-apl-…`). Segueix el
*Repartiment de continguts* de 4t, **sense el que Aplicades no fa**, que és el que
diu l'índex del llibre `4eso-apl` (§9 del seu `handout.md`):

| Es treu del Repartiment | Per què |
|---|---|
| Trigonometria (el sentit de la mesura sencer) | la via A mesura indirecta amb semblança i Pitàgores |
| Logaritmes i funció logarítmica | l'exponencial hi és com a fenomen; el logaritme, no |
| Variància i desviació típica | la dispersió és el recorregut i la desviació mitjana (`VETOS_CONSIGNA`) |
| Variacions, combinacions, Tartaglia i Newton | la combinatòria és recompte amb arbre, principi multiplicatiu i factorial |

Dotze sabers, amb les hores del document: comprensió lectora (16 h), nombres
reals (8), percentatge (12), repàs previ de Pitàgores i semblança (4), llenguatge
algebraic i identitats (8), equació de 2n grau (8), funció quadràtica (8),
magnituds inversament proporcionals (6), funció exponencial (6), variable
estadística (10), combinatòria (8) i probabilitat (10). Els sistemes d'equacions i
les inequacions de la UD10 del llibre **no hi són**: no són al Repartiment de 4t
(són de 3r). Les unitats del llibre (`llibre=[("4eso-apl", ud, …)]`) estan
referenciades, però, com a la resta, no es mostren.

El material ve de dos llocs:

- **`repas`** (219 ítems nous): els blocs que 1r, 2n i 3r no feien servir i que són de 4t
  (fórmula general i factorització de 2n grau, funcions quadràtiques i paràboles,
  IVA/interessos i percentatges encadenats, dispersió, probabilitat composta i
  condicionada, igualtats notables i successions).
- **`generadors.js`** (52 generadors, ~300 ítems del catàleg): allà on el banc no
  té nivell 1 o no té res (nombres reals, percentatges, equacions `x²=k`, vèrtex,
  hipèrbola, exponencial, recorregut, desviació mitjana, factorial, Laplace,
  condicionada…). Les comprovacions aritmètiques de `genera.js` els cobreixen.

**Per què `--afegeix-repas` i no una compilació completa.** El `repas` d'ara (1029
ítems) és més nou que el que va alimentar el `banc.js` de 1r–3r (892): té ítems
nous als sabers que ja hi eren, un `dif` recalibrat de 1 a 4 i alguna solució
corregida. Una compilació completa canviaria 1r, 2n i 3r, i un mateix codi de prova
donaria una altra prova. Per això s'afegeix el curs nou sense tocar res del que hi ha:

```sh
python3 tools/compila.py --afegeix-repas ../repas-main
```

Només refà els sabers que encara no són al `mapa.js`, i deixa 1r–3r **byte a byte** com
estaven (comprovat ítem per ítem). Posar al dia el banc de 1r–3r amb
el `repas` nou és una decisió a part, amb la compilació completa (`--repas`, `--llibre`);
vegeu el final de l'apartat de 4t Acadèmiques.
Els títols de les unitats de `4eso-apl` surten de la instantània `tools/llibre/4eso-apl.json`
(que es refà amb `tools/llibre_des_de_tex.py`), perquè aquest llibre viu a Overleaf i no
al repositori `llibre`.

Un detall de la interfície que això va destapar: l'id del curs ja no és el prefix de
quatre lletres dels sabers (`4eso-apl`, no `4eso`); `app.js` ho resol amb un mapa saber → curs.

---

## 4t d'ESO · Acadèmiques

És el cinquè curs (`id` `4eso-aca`, sabers `4eso-aca-…`) i segueix el *Repartiment de
continguts* de 4t **sencer**: tot el que fa Aplicades i, a més, el que Aplicades no fa.
Els catorze sabers repeteixen els d'Aplicades amb els mateixos sufixos i les mateixes
hores, més dos de nous (logaritmes i trigonometria) i algun d'ampliat:

| Saber de B | Hores | Què té respecte d'A |
|---|---|---|
| Logaritmes (`num-logaritmes`) | 4 | nou: definició, propietats, `log` i `ln` |
| Repàs previ a la trigonometria (`esp-repas`) | 4 | el mateix repàs que A, amb el nom de B |
| Trigonometria (`mes-trigonometria`) | 12 | nou: raons, angles notables, complementaris, reducció al 1r quadrant, teoremes del sinus i del cosinus |
| Funció exponencial i logarítmica (`alg-exponencial`) | 6 | s'hi afegeix el domini, la inversa i les bases 10 i *e* |
| Variable estadística (`est-variable`) | 10 | a més del recorregut i la desviació mitjana, **variància i desviació típica** (B no té `VETOS_CONSIGNA`) |
| Combinatòria (`est-combinatoria`) | 8 | a més de l'arbre i el factorial: variacions, variacions amb repetició, combinacions, Tartaglia i binomi de Newton |

**Com es comparteix el material.** Cada generador d'Aplicades declara els seus sabers
`4eso-apl-X`; la funció `reg()` de `generadors.js` hi afegeix sola el `4eso-aca-X`
corresponent. Així una pregunta nova d'A serveix a B sense tocar res; al revés no
passa: els generadors només de B (`trig-…`, `log-…`, `flog-…`, `com-variacions`,
`com-vr`, `com-combinacions`, `com-tartaglia`, `com-newton`, `est-variancia`) declaren
directament `4eso-aca-…`. Els ítems de `repas` es comparteixen igual: si ja eren al banc
per A, només guanyen l'id del saber de B (el registre no canvia). Els deu ítems de
variància que A veta, els té B.

**Llibre.** Les unitats són les de `4eso` (4t B, UD1–UD10), amb els títols a
`tools/llibre/4eso.json`, generat amb `tools/llibre_des_de_tex.py`. La UD8 (vectors i
rectes) no és al Repartiment i no té cap saber.

**Cobertura.** Trigonometria, logaritmes i funció exponencial i logarítmica només tenen
preguntes de nivell 1: el banc `repas` no té material d'aquests continguts (el mateix
passa amb l'exponencial d'A).

**1r–3r al dia amb el `repas` nou.** Després d'afegir 4t amb `--afegeix-repas`, s'ha fet la
compilació completa (`--repas ../repas-main --llibre ../llibre-main`). Canvis: 57 ítems
nous (1.644 en total, dels quals 878 de `repas`), `dif` recalibrat (86 ítems canvien de nivell),
15 solucions i 6 notes corregides i dos ítems de resposta múltiple més als exclosos
(`f11-369a/b`). Els 766 ítems propis no es mouen. Una prova de 1r–3r generada abans
d'aquest canvi pot donar una altra prova en regenerar-la. El llibre es tria ara pels
llibres que referencia el mapa (`cursos_de_llibre`), no pels cursos de l'eina.

---

## Canviar el currículum

El mapa és un sol fitxer de Python, `tools/mapa_curricular.py`. Cada saber és una
entrada com aquesta:

```python
dict(id="2eso-alg-equacions", sentit="algebraic",
     titol="Equació de 1r grau", hores=9,
     detall="ax=b; ax+b=c. Resolució agrupant termes…",
     repas=[(5, "primer_grau", None),            # (full, bloc, exercicis)
            (5, "problemes", [91, 92, 99, 100])], # None = tot el bloc
     llibre=[("2eso", 4, None)],                  # (curs, unitat, activitats)
     bogdan=["equacions-1r2n-grau"]),
```

Després es recompila:

```sh
python3 tools/compila.py --repas ../repas-main --llibre ../llibre-main
```

(Amb el `repas` actual, aquesta ordre també canvia 1r–3r; per afegir només un curs nou,
vegeu `--afegeix-repas` a la secció de 4t.)

L'informe que surt per pantalla diu, saber per saber, quants ítems hi han quedat
i com estan repartits per dificultat, i marca amb `!!` els que s'han quedat a
zero. La compilació és determinista: entrades iguals, sortida idèntica.

Fins ara no ho era, tot i que aquí ja ho deia: les variants d'un mateix
generador s'ordenaven tal com sortien d'un `set` de Python, i aquest ordre
canvia a cada execució. Com que l'atzar de la composició recorre aquestes
llistes, un mateix codi de prova donava una altra prova després de cada
recompilació. `tools/prova_compilacio.py` ho vigila.

**Si només has tocat `generadors.js`** (o els títols, les hores o les
referències de `mapa_curricular.py`), no cal tenir a mà `repas` ni el llibre:

```sh
python3 tools/compila.py --nomes-propis
```

Refà el material propi i el mapa i reaprofita la part de repàs del `banc.js` que
ja hi ha. Sense cap canvi, dona un `banc.js` idèntic byte a byte. El que no pot
fer és canviar quins ítems de repàs van a cada saber (la llista `repas`, els
`VETOS`, els `EXCLOSOS`): per a això cal la compilació completa.

La compilació s'atura si el nivell que declara un generador no és el que mesura
`calcula_nivell`: el navegador fa servir el declarat per a les variants noves
(el dau, el `+` i el selector de nivell de cada pregunta) i no el pot mesurar.

**Decisions del mapa que potser vols canviar**, i que són meves, no del document:

- La fracció generatriu de decimals periòdics està a *Fraccions i decimals* de
  1r. Al banc, els exercicis 27–33 barregen periòdic pur i mixt, que molts
  departaments porten a 3r. Ara mateix només s'hi assigna l'exercici 27
  (decimals exactes); els altres no entren enlloc.
- *Angles* surt dos cops a 1r (a Sentit espacial i a Sentit de la mesura) perquè
  el document del departament ho fa així. Comparteixen l'únic ítem que hi ha, i
  per això marcar-los tots dos no dona dues preguntes.
- *Escala* de 1r hereta els 19 ítems del Full 8, que inclouen escales amb canvi
  d'unitats: per a 1r potser són massa.

---

## Comprovar que tot funciona

```sh
node tools/tests.js               # 200 comprovacions de la lògica, cap dependència
node tools/genera.js --comprova   # els 131 generadors sobre 26 200 variants
python3 tools/prova_compilacio.py # banc.js i mapa.js al dia, compilació determinista
node tools/prova.js               # unes 75 comprovacions en un navegador de debò
```

Totes quatre acaben amb codi 1 si alguna cosa falla. `prova.js` abans només
escrivia per pantalla i acabava sempre bé: un «*** BUIDA ***» passava si ningú
llegia la sortida. Necessita Playwright (`npm install --no-save playwright` i
`npx playwright install chromium`) i no deixa cap fitxer a l'arbre.

`prova.js` comprova, entre altres coses, que el full surti imprès des de
qualsevol de les tres pestanyes de pantalla estreta. No és paranoia: en imprimir, el navegador
mesura les media queries contra l'amplada del **paper** (uns 794 px a A4) i no
contra la de la finestra, o sigui que la maquetació estreta s'activa sempre. Amb
les regles de pantalla escrites com `@media (max-width:900px)` en comptes de
`@media screen and (max-width:900px)`, la regla que amaga el full a la pestanya
«Continguts» s'aplicava també al paper i sortia un full en blanc. També
comprova que el comptador de pàgines digui el mateix que el PDF real, que l'adreça torni el
mateix full i que una adreça mal formada no trenqui res.

`tests.js` comprova les coses que fan mal en paper: que els punts sumin
exactament el total demanat (o el mínim assolible, si el terra de 0,25 el puja), que no es repeteixi cap pregunta (ni cap exercici pare
mentre en quedin d'altres), i que el mateix codi doni sempre el mateix examen.

---

## GitHub: pujades per ZIP

- **`.github/workflows/unzip-upload.yml`**: un ZIP pujat a `_uploads/` es descomprimeix a
  l'arrel, s'esborra i se'n fa un commit. El commit **no** porta «[skip ci]», perquè
  Cloudflare no el publicaria.
- **`.github/workflows/tests.yml`** executa les quatre proves (la del navegador, amb Playwright)
  a cada canvi a `main` i a cada pull request, i també després de cada ZIP (el llança
  `unzip-upload.yml`). No escriu res al repositori. Pestanya **Actions**: verd, tot bé;
  vermell, clica-hi i surt quina comprovació ha fallat.
- Els fitxers de `.github/workflows/` no poden arribar dins d'un ZIP: el bot no hi té permís.
  Es creen i s'editen des de la web de GitHub.

---

## El que aquesta eina no fa

- **No corregeix.** El full de correcció porta la solució i els passos, però la
  correcció d'una resposta oberta és feina humana i ha de continuar sent-ho.
- **No sap qui és l'alumne.** No hi ha comptes, ni base de dades, ni res que
  surti del navegador. Si vols saber què ha practicat un alumne abans de decidir
  què li preguntes, això ho fa l'analitzador de `repas` amb el codi de
  verificació; són dues eines separades a propòsit.

---

## Avís

El **full de correcció** i el fitxer `assets/js/banc.js` porten totes les
solucions. Les solucions van codificades en base64 dins de `banc.js` — que és
higiene, no seguretat: qualsevol que sàpiga què és el base64 les llegeix. Si
publiques aquest lloc en un servidor, publica'l en un lloc que l'alumnat no
pugui obrir, igual que ja fas amb els `REVISIO-fullN.html` de `repas`.

El mateix val per al repositori de GitHub: si és **públic**, `banc.js` hi és a
la vista de tothom.

<!-- atribucio-centre:inici -->

---

Material desenvolupat per **David Arso Civil** per al Departament de Matemàtiques de l'INS Miquel Tarradell.
Contingut sota CC BY-NC-SA 4.0, codi sota llicència MIT. Vegeu [`LLICENCIA.md`](LLICENCIA.md).

<!-- atribucio-centre:final -->
